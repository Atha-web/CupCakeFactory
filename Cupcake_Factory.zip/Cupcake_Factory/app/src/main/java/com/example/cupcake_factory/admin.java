package com.example.cupcake_factory;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class admin extends AppCompatActivity {

    Button btncategory, btnaddproduct, btnviewproduct, btnlogout;
    private DBHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        dbHelper = new DBHelper(this);



        btncategory=(Button) findViewById(R.id.btn_A_Category);
        btnaddproduct=(Button) findViewById(R.id.btn_A_product);
        btnviewproduct=(Button) findViewById(R.id.btn_A_Viewproduct);
        btnlogout=(Button) findViewById(R.id.btnA_logout);


        btncategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentc=new Intent(admin.this,category.class);
                startActivity(intentc);
            }
        });

        btnaddproduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentadd=new Intent(admin.this,product.class);
                startActivity(intentadd);
            }
        });


        btnlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentl=new Intent(admin.this,MainActivity.class);
                startActivity(intentl);
            }
        });



        btnviewproduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor t = dbHelper.getinfo();
                if (t.getCount() == 0) {
                    Toast.makeText(admin.this, "No Product ", Toast.LENGTH_SHORT).show();
                }
                StringBuffer buffer = new StringBuffer();
                while (t.moveToNext()) {
                    buffer.append("Product name: " + t.getString(1) + "\n");
                    buffer.append("Price: " + t.getString(3) + "\n");
                    buffer.append("Quantity: " + t.getString(4) + "\n\n\n");
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(admin.this);
                builder.setCancelable(true);
                builder.setTitle("Product List");
                builder.setMessage(buffer.toString());
                builder.show();
            }
        });
    }
}