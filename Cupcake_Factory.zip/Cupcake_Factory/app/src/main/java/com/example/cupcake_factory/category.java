package com.example.cupcake_factory;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class category extends AppCompatActivity {

    EditText EditTextCategoryId, EditTextCategoryName;
    Button ButtonInsertCategory,btnbackCA;

    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        dbHelper = new DBHelper(this);


        EditTextCategoryId = (EditText) findViewById(R.id.txt_C_Category_Id);
        EditTextCategoryName = (EditText) findViewById(R.id.txt_C_Category_Name);

        ButtonInsertCategory = (Button) findViewById(R.id.btn_C_Category_Insert);
        btnbackCA=(Button) findViewById(R.id.btnC_back);

        ButtonInsertCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (EditTextCategoryId.getText().toString().isEmpty() || EditTextCategoryName.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please Enter ID & Name", Toast.LENGTH_LONG).show();
                } else {
                    Category_class category_class = new Category_class(EditTextCategoryId.getText().toString(), EditTextCategoryName.getText().toString());
                    if (dbHelper.InsertCategory(category_class)) {
                        Toast.makeText(getApplicationContext(), "Category added ", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Category Not Added", Toast.LENGTH_LONG).show();
                    }
                }

            }
        });

        btnbackCA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentCa=new Intent(category.this,admin.class);
                startActivity(intentCa);
            }
        });
    }
}