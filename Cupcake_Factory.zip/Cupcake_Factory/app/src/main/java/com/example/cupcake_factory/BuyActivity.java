package com.example.cupcake_factory;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class BuyActivity extends AppCompatActivity {

    EditText EditTextInvoiceId, EditTextProductId, EditTextProductName, EditTextPrice, EditTextCategory, EditTextQuantity,EditTextBuyQuantity, EditTextTotal;
    Button ButtonSearchProduct, ButtonBuyProduct;

    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy);


        dbHelper = new DBHelper(this);

        EditTextInvoiceId=(EditText)findViewById(R.id.txtP_Invoiceid);
        EditTextProductId=(EditText)findViewById(R.id.txtP_Productid);
        EditTextProductName=(EditText)findViewById(R.id.txtP_ProductName);
        EditTextPrice=(EditText)findViewById(R.id.txtP_Productprice);
        EditTextCategory=(EditText)findViewById(R.id.txtP_Categoryid);
        EditTextQuantity=(EditText)findViewById(R.id.txtP_Productqty);
        EditTextBuyQuantity=(EditText)findViewById(R.id.txtP_Needbuy);
        EditTextTotal=(EditText)findViewById(R.id.txtP_Total);

        ButtonSearchProduct= (Button)findViewById(R.id.btnP_search);
        ButtonBuyProduct= (Button)findViewById(R.id.btnP_purches);

        ButtonSearchProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String PName=EditTextProductName.getText().toString();

                ArrayList<Product_class> Product_classList=dbHelper.SearchProduct(PName);

                if(Product_classList.size()!=0)
                {
                    Product_class product_class= Product_classList.get(0);
                    EditTextProductId.setText(product_class.getProductID());
                    EditTextQuantity.setText((String.valueOf(product_class.getQuantity())));
                    EditTextPrice.setText((String.valueOf(product_class.getPrice())));
                    EditTextCategory.setText(product_class.getCategoryID());

                    Toast.makeText(getApplicationContext(),"Item found", Toast.LENGTH_LONG).show();


                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Item Not Available", Toast.LENGTH_LONG).show();
                }
            }
        });

        ButtonBuyProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int total = Integer.parseInt(EditTextBuyQuantity.getText().toString())* Integer.parseInt(EditTextPrice.getText().toString());

                dbHelper.buyproduct(EditTextProductId.getText().toString(),Integer.parseInt(EditTextBuyQuantity.getText().toString()));

                EditTextTotal.setText(String.valueOf(total));

                Buy_class buy_class=new Buy_class(EditTextInvoiceId.getText().toString(), EditTextProductId.getText().toString(),Integer.parseInt(EditTextPrice.getText().toString()),Integer.parseInt(EditTextBuyQuantity.getText().toString()),total);

                if(dbHelper.InsertInvoice(buy_class))
                {
                    Toast.makeText(getApplicationContext(),"Thank you! For your Order",Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Please try again",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}