package com.example.cupcake_factory;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class register extends AppCompatActivity {

    EditText editTextusername, editTextPassword,editTextConfirmPassword;
    Spinner SpinnerUserType;
    Button btnRegister;

    TextView txtlogin;

    private DBHelper dbHelper;

    String UserType[]={"Admin","Customer"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        dbHelper=new DBHelper(this);


        editTextusername=(EditText) findViewById(R.id.txt_R_UserName);
        editTextPassword=(EditText) findViewById(R.id.txt_R_Password);
        editTextConfirmPassword=(EditText) findViewById(R.id.txt_R_ConPassword);
        txtlogin=(TextView)findViewById(R.id.R_Login);

        btnRegister=(Button) findViewById(R.id.btn_R_RegisterButton);
        SpinnerUserType=(Spinner) findViewById(R.id.R_sp_UserType);

        ArrayAdapter ad=new ArrayAdapter(this, android.R.layout.simple_spinner_item,UserType);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SpinnerUserType.setAdapter(ad);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (editTextusername.getText().toString().isEmpty() || editTextPassword.getText().toString().isEmpty() || editTextConfirmPassword.getText().toString().isEmpty())
                {
                    Toast.makeText(getApplicationContext(), "Please Enter all fields", Toast.LENGTH_SHORT).show();
                }
                else if (editTextPassword.getText().toString().length()<5)
                {
                    Toast.makeText(getApplicationContext(), "please enter 5  character password", Toast.LENGTH_SHORT).show();
                }
                else if (!editTextPassword.getText().toString().equals(editTextConfirmPassword.getText().toString()))
                {
                    Toast.makeText(getApplicationContext(), "Confirm password is not Similar", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    User user=new User(editTextusername.getText().toString(),editTextPassword.getText().toString(),SpinnerUserType.getSelectedItem().toString());
                    if (dbHelper.RegisterUser(user))
                    {
                        Toast.makeText(getApplicationContext(),"Account created",Toast.LENGTH_LONG).show();
                        Toast.makeText(getApplicationContext(),editTextusername.getText().toString()+",Login to Explore "+SpinnerUserType.getSelectedItem().toString(),Toast.LENGTH_LONG).show();
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Account create Failure, Try again", Toast.LENGTH_SHORT).show();
                    }

                }
            }

        });

        txtlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLo=new Intent(register.this,Loginact.class);
                startActivity(intentLo);
            }
        });

    }
}