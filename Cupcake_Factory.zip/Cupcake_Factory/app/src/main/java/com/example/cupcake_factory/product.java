package com.example.cupcake_factory;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.Vector;

public class product extends AppCompatActivity {

    EditText EditTextProductId,EditTextProductName,EditTextPrice,EditTextQuantity;
    Button ButtonInsertProduct, btnupdate, btndelete;
    Spinner SpinnerCategoryId;

    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);

        dbHelper=new DBHelper(this);

        EditTextProductId=(EditText)findViewById(R.id.txtProduct_Id);
        EditTextProductName=(EditText)findViewById(R.id.txtProduct_Name);
        EditTextPrice=(EditText)findViewById(R.id.txtProduct_Price);
        EditTextQuantity=(EditText)findViewById(R.id.txtProduct_Quantity);

        ButtonInsertProduct=(Button)findViewById(R.id.btnProduct_Insert);
        btnupdate=findViewById(R.id.btnProduct_update);
        btndelete=findViewById(R.id.btnProduct_delte);

        SpinnerCategoryId=(Spinner)findViewById(R.id.spProduct);

        Vector<String> vecCategory= dbHelper.getCategory_Name();

        ArrayAdapter ad=new ArrayAdapter(this, android.R.layout.simple_spinner_item,vecCategory);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SpinnerCategoryId.setAdapter(ad);

        ButtonInsertProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (EditTextProductId.getText().toString().isEmpty() || EditTextProductName.getText().toString().isEmpty() || EditTextPrice.getText().toString().isEmpty() || EditTextQuantity.getText().toString().isEmpty())
                {
                    Toast.makeText(getApplicationContext(), "All Fields Must be Filled", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    String CategoryId= dbHelper.getCategory_Id(SpinnerCategoryId.getSelectedItem().toString());

                    Product_class product_class=new Product_class(EditTextProductId.getText().toString(), EditTextProductName.getText().toString(),CategoryId,Integer.parseInt(EditTextPrice.getText().toString()),Integer.parseInt(EditTextQuantity.getText().toString()));

                    if(dbHelper.InsertProduct(product_class))
                    {
                        Toast.makeText(getApplicationContext(),"Product added to the List",Toast.LENGTH_LONG).show();
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),"Product Not Inserted Try again",Toast.LENGTH_LONG).show();
                    }
                }
            }
        });

        btnupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ProductIdtxt= EditTextProductId.getText().toString();
                String ProductName= EditTextProductName.getText().toString();
                String Pricetxt= EditTextPrice.getText().toString();
                String Quantitytxt= EditTextQuantity.getText().toString();

                Boolean checkupdate = dbHelper.updatedata(ProductIdtxt, ProductName, Pricetxt, Quantitytxt );
                if (checkupdate==true)
                    Toast.makeText(product.this, "Updated", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(product.this, "Failed", Toast.LENGTH_SHORT).show();

            }
        });

        btndelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ProductIdtxt= EditTextProductId.getText().toString();

                Boolean checkdelete = dbHelper.deletedata(ProductIdtxt);
                if (checkdelete==true)
                    Toast.makeText(product.this, "Deleted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(product.this, "Failed", Toast.LENGTH_SHORT).show();
            }


        });

    }
}