package com.example.cupcake_factory;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class Loginact extends AppCompatActivity {

    EditText EdittextLusername, EdittextLpassword;
    Button btnLLogin;

    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginact);

        dbHelper=new DBHelper(this);


        EdittextLusername=(EditText)findViewById(R.id.L_Username);
        EdittextLpassword=(EditText)findViewById(R.id.L_Password);

        btnLLogin=(Button)findViewById(R.id.btn_L_Login);

        btnLLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<User> userDetails= dbHelper.ValidLogin(EdittextLusername.getText().toString(),EdittextLpassword.getText().toString());

                if (userDetails.size()!=0)
                {
                    User user= userDetails.get(0);
                    String UserType=user.getUserType();

                    Toast.makeText(getApplicationContext(), "Welcome" +UserType, Toast.LENGTH_SHORT).show();
                    if (UserType.equals("Admin"))
                    {
                        Intent intentRegister = new Intent(Loginact.this,admin.class);
                        startActivity(intentRegister);

                    }
                    else
                    {
                        Intent intentRegister = new Intent(Loginact.this,customer.class);
                        startActivity(intentRegister);
                    }
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Username or Password invalid", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}